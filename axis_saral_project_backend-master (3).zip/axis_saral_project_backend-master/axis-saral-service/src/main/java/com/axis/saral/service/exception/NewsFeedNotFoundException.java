package com.axis.saral.service.exception;

public class NewsFeedNotFoundException extends RuntimeException {

	private static final long serialVersionUID = -170L;

	public NewsFeedNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	public NewsFeedNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
