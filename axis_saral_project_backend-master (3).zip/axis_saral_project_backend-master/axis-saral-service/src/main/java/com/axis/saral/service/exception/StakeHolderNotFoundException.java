package com.axis.saral.service.exception;

public class StakeHolderNotFoundException extends RuntimeException {

	private static final long serialVersionUID = -190L;

	public StakeHolderNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	public StakeHolderNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
