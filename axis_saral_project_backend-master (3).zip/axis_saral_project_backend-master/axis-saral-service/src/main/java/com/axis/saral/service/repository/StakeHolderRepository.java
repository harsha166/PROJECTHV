package com.axis.saral.service.repository;

import org.springframework.data.repository.CrudRepository;

import com.axis.saral.service.entity.StakeHolder;

public interface StakeHolderRepository extends CrudRepository<StakeHolder, String> {

}
