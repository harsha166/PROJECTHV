package com.axis.saral.service.exception;

public class CommentNotFoundException extends RuntimeException {

	private static final long serialVersionUID = -180L;

	public CommentNotFoundException() {
		// TODO Auto-generated constructor stub
	}

	public CommentNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
