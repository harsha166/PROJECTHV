package com.axis.saral.employeeservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AxisSaralEmployeeserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
