package com.axis.saral.eurekaserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AxisSaralEurekaServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
