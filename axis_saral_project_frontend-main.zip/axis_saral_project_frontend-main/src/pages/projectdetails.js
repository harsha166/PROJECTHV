export default function ProjectDetails() {
    return <h1>projectdetails</h1>
  }