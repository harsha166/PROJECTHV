export default function SalaryDetails() {
    return <h1>SalaryDetails</h1>
}